/**
 * Browser Supabase client factory (placeholder).
 *
 * When the Supabase integration is connected, install `@supabase/ssr` and
 * implement this with the injected env vars:
 *
 *   import { createBrowserClient } from '@supabase/ssr'
 *   export function createClient() {
 *     return createBrowserClient(
 *       process.env.NEXT_PUBLIC_SUPABASE_URL!,
 *       process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
 *     )
 *   }
 *
 * Kept as a stub so no secrets are referenced before the integration exists.
 */
export function isSupabaseConfigured(): boolean {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  )
}
