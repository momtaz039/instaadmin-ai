/**
 * Server Supabase client factory (placeholder).
 *
 * When the Supabase integration is connected, install `@supabase/ssr` and
 * implement using the request cookie store (Next.js 16 — cookies() is async):
 *
 *   import { createServerClient } from '@supabase/ssr'
 *   import { cookies } from 'next/headers'
 *   export async function createClient() {
 *     const cookieStore = await cookies()
 *     return createServerClient(
 *       process.env.SUPABASE_URL!,
 *       process.env.SUPABASE_ANON_KEY!,
 *       {
 *         cookies: {
 *           getAll: () => cookieStore.getAll(),
 *           setAll: (list) => list.forEach(({ name, value, options }) =>
 *             cookieStore.set(name, value, options)),
 *         },
 *       },
 *     )
 *   }
 *
 * Row Level Security (see supabase/policies.sql) must be enabled on every
 * table so multi-tenant data stays isolated by organization/workspace.
 */
export const SUPABASE_SETUP_REQUIRED = true
